function index = root(tab, index)

while index ~= tab(index)
    index = tab(index);
end

end